package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.UserProfile
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AuthRepository(
    private val context: Context,
    private val firestore: FirebaseFirestore
) {
    private val auth: FirebaseAuth = Firebase.auth
    private val credentialManager = CredentialManager.create(context)

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun getUserProfile(uid: String): UserProfile? = withContext(Dispatchers.IO) {
        val docRef = firestore.collection("users").document(uid)
        try {
            val snapshot = docRef.get().await()
            if (snapshot.exists()) {
                snapshot.toObject(UserProfile::class.java)
            } else {
                null
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, docRef.path)
            null
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: return@withContext Result.failure(
            IllegalStateException("يجب تسجيل الدخول أولاً")
        )
        val docRef = firestore.collection("users").document(uid)
        try {
            val gameName = profile.inGameName.ifBlank { profile.fullName.ifBlank { "لاعب ببجي" } }
            val gameId = profile.inGameId.ifBlank { profile.username.ifBlank { uid.take(8) } }
            val payload = mutableMapOf<String, Any?>(
                "userId" to uid,
                "inGameName" to gameName,
                "inGameId" to gameId,
                "fullName" to gameName,
                "username" to gameId,
                "email" to (profile.email.ifBlank { auth.currentUser?.email ?: "player@ammarscrims.com" }),
                "accountStatus" to "active",
                "role" to if (auth.currentUser?.email == "youss3fmohmmed68@gmail.com") "admin" else profile.role,
                "createdAt" to FieldValue.serverTimestamp(),
                "lastLoginAt" to FieldValue.serverTimestamp()
            )
            if (!profile.photoURL.isNullOrBlank()) payload["photoURL"] = profile.photoURL

            val existing = docRef.get().await()
            if (existing.exists()) {
                // Keep the original creation timestamp; Firestore rules reject replacing it.
                payload.remove("createdAt")
                docRef.update(payload).await()
            } else {
                docRef.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun signInWithEmailPassword(email: String, password: String): Result<FirebaseUser> =
        withContext(Dispatchers.IO) {
            try {
                val result = auth.signInWithEmailAndPassword(email.trim(), password).await()
                val user = result.user ?: throw IllegalStateException("تعذر تحميل بيانات الحساب")
                // Update last login without replacing the account creation timestamp.
                val profileRef = firestore.collection("users").document(user.uid)
                val profile = profileRef.get().await()
                if (profile.exists()) {
                    if (profile.getString("accountStatus") == "suspended") {
                        throw IllegalStateException("هذا الحساب موقوف، تواصل مع إدارة التطبيق")
                    }
                    // Login must not fail just because an older profile has legacy fields/rules.
                    try {
                        profileRef.update("lastLoginAt", FieldValue.serverTimestamp()).await()
                    } catch (updateError: Exception) {
                        Log.w("Auth", "Could not update lastLoginAt", updateError)
                    }
                } else {
                    val created = UserProfile(
                        userId = user.uid,
                        fullName = user.displayName ?: email.substringBefore("@"),
                        username = email.substringBefore("@"),
                        email = user.email ?: email,
                        provider = "password"
                    )
                    val saved = saveUserProfile(created)
                    if (saved.isFailure) throw (saved.exceptionOrNull() ?: Exception("تعذر حفظ ملف الحساب"))
                }
                Result.success(user)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Do not leave a signed-in session behind when profile validation/loading fails.
                auth.signOut()
                Result.failure(e)
            }
        }

    suspend fun createAccountWithEmailPassword(
        gameName: String,
        gameId: String,
        email: String,
        password: String
    ): Result<FirebaseUser> = withContext(Dispatchers.IO) {
        var createdUser: FirebaseUser? = null
        try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), password).await()
            val user = result.user ?: throw IllegalStateException("تعذر إنشاء الحساب")
            createdUser = user
            val profile = UserProfile(
                userId = user.uid,
                inGameName = gameName.trim(),
                inGameId = gameId.trim(),
                fullName = gameName.trim(),
                username = gameId.trim(),
                email = user.email ?: email.trim(),
                provider = "password",
                role = "player"
            )
            val saved = saveUserProfile(profile)
            if (saved.isFailure) throw (saved.exceptionOrNull() ?: Exception("تعذر حفظ بيانات الحساب"))
            Result.success(user)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Do not leave a half-created Firebase account if its required profile could not be saved.
            if (createdUser != null) {
                try { createdUser.delete().await() } catch (_: Exception) { }
                auth.signOut()
            }
            Result.failure(e)
        }
    }

    suspend fun sendPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            auth.sendPasswordResetEmail(email.trim()).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun friendlyAuthError(error: Throwable): String {
        return when (error) {
            is FirebaseAuthInvalidUserException -> "الحساب غير موجود أو تم تعطيله"
            is FirebaseAuthInvalidCredentialsException -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
            is FirebaseAuthUserCollisionException -> "هذا البريد مسجل بالفعل، جرّب تسجيل الدخول"
            else -> when {
                error.message?.contains("network", true) == true -> "تعذر الاتصال بالإنترنت، حاول مرة أخرى"
                error.message?.contains("password", true) == true -> "كلمة المرور غير صحيحة أو لا تستوفي الشروط"
                error.message?.contains("PERMISSION_DENIED", true) == true -> "تعذر حفظ بيانات الحساب. راجع صلاحيات Firebase Firestore"
                else -> error.localizedMessage ?: "حدث خطأ، حاول مرة أخرى"
            }
        }
    }

    fun onGoogleSignInClicked(
        activity: Activity,
        scope: CoroutineScope,
        onSuccess: (FirebaseUser) -> Unit,
        onError: (String) -> Unit,
        onCancelled: () -> Unit
    ) {
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            onError("إعدادات Google غير مكتملة")
            return
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        // Ensure profile exists in Firestore
                        val existingProfile = getUserProfile(user.uid)
                        if (existingProfile == null) {
                            val newProfile = UserProfile(
                                userId = user.uid,
                                fullName = user.displayName ?: "لاعب ببجي",
                                username = (user.email?.substringBefore("@") ?: "Player_${user.uid.take(6)}"),
                                email = user.email ?: "",
                                photoURL = user.photoUrl?.toString(),
                                provider = "google",
                                role = if (user.email == "youss3fmohmmed68@gmail.com") "admin" else "player"
                            )
                            val saved = saveUserProfile(newProfile)
                            if (saved.isFailure) {
                                auth.signOut()
                                onError(friendlyAuthError(saved.exceptionOrNull()!!))
                                return@launch
                            }
                        }
                        onSuccess(user)
                    } else {
                        onError("فشل جلب بيانات المستخدم")
                    }
                } else {
                    onError("نوع الاعتماد غير متوافق")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("Auth", "Google Sign-In cancelled: ${e.message}")
                onCancelled()
            } catch (e: Exception) {
                Log.e("Auth", "Google Sign-In error", e)
                onError(e.localizedMessage ?: "حدث خطأ أثناء تسجيل الدخول بواسطة Google")
            }
        }
    }

    fun attemptAutoSignIn(
        scope: CoroutineScope,
        onSuccess: (FirebaseUser) -> Unit,
        onUnauthenticated: () -> Unit
    ) {
        val user = auth.currentUser
        if (user != null) {
            onSuccess(user)
            return
        }

        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            onUnauthenticated()
            return
        }

        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(true)
            .setServerClientId(clientId)
            .setAutoSelectEnabled(true)
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(context, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    val signedInUser = authResult.user
                    if (signedInUser != null) {
                        onSuccess(signedInUser)
                    } else {
                        onUnauthenticated()
                    }
                } else {
                    onUnauthenticated()
                }
            } catch (e: Exception) {
                onUnauthenticated()
            }
        }
    }

    fun signOut(
        scope: CoroutineScope,
        onComplete: () -> Unit
    ) {
        scope.launch {
            withContext(NonCancellable) {
                try {
                    credentialManager.clearCredentialState(ClearCredentialStateRequest())
                } catch (e: Exception) {
                    Log.w("Auth", "Failed to clear credential state: ${e.message}")
                } finally {
                    auth.signOut()
                    onComplete()
                }
            }
        }
    }
}
