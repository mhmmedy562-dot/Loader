<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/9260595b-cfc8-41b7-8042-e7b8618b5291

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.


## Firebase Authentication setup (required)

Before testing account registration or login, open Firebase Console for the project used by `app/google-services.json`:

1. Open **Authentication → Sign-in method** and enable **Email/Password**.
2. Enable **Google** if you want the Google sign-in button to work.
3. In **Project settings → Your apps → Android app**, confirm the package name is exactly `com.aistudio.ammarscrims.vpxrtw`.
4. Add the SHA-1 certificate fingerprint for the exact key used to sign the APK (debug and release keys can have different fingerprints). After changing OAuth fingerprints, download the updated `google-services.json` and replace `app/google-services.json`.
5. Publish the included Firestore rules to the named database configured in `firebase.json`.

The login field accepts the account's **email address** and password. PUBG player ID is stored in the profile, but resolving a player ID to an email before authentication needs a trusted backend endpoint; the app does not expose a public user-directory query.
