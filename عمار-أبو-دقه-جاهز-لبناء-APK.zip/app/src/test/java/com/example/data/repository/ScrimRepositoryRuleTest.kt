package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ScrimRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun observeScrims_authenticatedUser_emitsScrims() = runBlocking {
        signInTestUser("youss3fmohmmed68@gmail.com")
        val repository = ScrimRepository(firestore)
        repository.seedInitialScrimsIfEmpty()

        signInTestUser("player1@test.com")
        val scrims = withTimeout(5000L) {
            repository.observeScrims().first { it.isNotEmpty() }
        }
        assertTrue(scrims.isNotEmpty())
        assertNotNull(scrims.first().title)
    }

    @Test
    fun registerForScrim_authenticatedUser_succeeds() = runBlocking {
        signInTestUser("youss3fmohmmed68@gmail.com")
        val repository = ScrimRepository(firestore)
        repository.seedInitialScrimsIfEmpty()

        val uniqueEmail = "player_${System.currentTimeMillis()}@test.com"
        signInTestUser(uniqueEmail)
        val playerRepo = ScrimRepository(firestore)

        val result = withTimeout(5000L) {
            playerRepo.registerForScrim("scrim_friday_weekly")
        }
        if (result.isFailure) {
            System.err.println("registerForScrim failed: " + result.exceptionOrNull()?.message)
            result.exceptionOrNull()?.printStackTrace()
        }
        assertTrue(result.isSuccess)

        // Test unregister
        val unregResult = withTimeout(5000L) {
            playerRepo.unregisterFromScrim("scrim_friday_weekly")
        }
        assertTrue("Unregistration from scrim must succeed", unregResult.isSuccess)
    }
}

