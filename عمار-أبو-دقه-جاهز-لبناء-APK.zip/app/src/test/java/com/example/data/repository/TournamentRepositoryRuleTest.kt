package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TournamentRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun observeTournaments_authenticatedUser_emitsTournaments() = runBlocking {
        signInTestUser("youss3fmohmmed68@gmail.com")
        val repository = TournamentRepository(firestore)
        repository.seedInitialTournamentsIfEmpty()

        signInTestUser("player1@test.com")
        val tournaments = withTimeout(5000L) {
            repository.observeTournaments().first { it.isNotEmpty() }
        }
        assertTrue(tournaments.isNotEmpty())
        assertNotNull(tournaments.first().title)
    }

    @Test
    fun registerAndUnregisterTournament_atomicTransactions_succeed() = runBlocking {
        signInTestUser("youss3fmohmmed68@gmail.com")
        val repository = TournamentRepository(firestore)
        repository.seedInitialTournamentsIfEmpty()

        val uniqueEmail = "player_tournament_${System.currentTimeMillis()}@test.com"
        signInTestUser(uniqueEmail)
        val playerRepo = TournamentRepository(firestore)

        // 1. Register
        val regResult = withTimeout(5000L) {
            playerRepo.registerForTournament("tournament_ammar_grand")
        }
        assertTrue("Registration must succeed", regResult.isSuccess)

        // 2. Unregister
        val unregResult = withTimeout(5000L) {
            playerRepo.unregisterFromTournament("tournament_ammar_grand")
        }
        assertTrue("Unregistration must succeed", unregResult.isSuccess)
    }
}
