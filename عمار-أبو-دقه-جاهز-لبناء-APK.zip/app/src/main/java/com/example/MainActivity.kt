package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.data.repository.AuthRepository
import com.example.data.repository.NotificationRepository
import com.example.data.repository.ScrimRepository
import com.example.data.repository.StatsRepository
import com.example.data.repository.TournamentRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.home.HomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AppContent()
            }
        }
    }
}

@Composable
fun AppContent() {
    val context = LocalContext.current
    val databaseId = context.getString(R.string.firestore_database_id)
    val firestore = remember { FirebaseFirestore.getInstance(databaseId) }

    val authRepository = remember { AuthRepository(context, firestore) }
    val scrimRepository = remember { ScrimRepository(firestore) }
    val tournamentRepository = remember { TournamentRepository(firestore) }
    val notificationRepository = remember { NotificationRepository(firestore) }
    val statsRepository = remember { StatsRepository(firestore) }

    var currentUser by remember { mutableStateOf(Firebase.auth.currentUser) }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            currentUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    if (currentUser == null) {
        AuthScreen(
            authRepository = authRepository,
            onAuthSuccess = {
                currentUser = Firebase.auth.currentUser
            }
        )
    } else {
        val uid = currentUser!!.uid
        key(uid) {
            HomeScreen(
                currentUserId = uid,
                authRepository = authRepository,
                scrimRepository = scrimRepository,
                tournamentRepository = tournamentRepository,
                notificationRepository = notificationRepository,
                statsRepository = statsRepository,
                onSignOut = {
                    currentUser = null
                }
            )
        }
    }
}
