package com.example.data.repository

import com.example.data.model.Tournament
import com.example.data.util.OperationType
import com.example.data.util.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class TournamentRepository(private val db: FirebaseFirestore) {

    private val auth = Firebase.auth

    fun observeTournaments(): Flow<List<Tournament>> = flow {
        val path = "tournaments"
        emitAll(
            db.collection(path)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(Tournament::class.java)
                }
                .catch { error ->
                    val firestoreError = generateSequence(error) { it.cause }
                        .filterIsInstance<FirebaseFirestoreException>()
                        .firstOrNull()
                    if (firestoreError == null && error is CancellationException) throw error
                    val exceptionToLog = firestoreError ?: (error as? Exception)
                    if (exceptionToLog != null && auth.currentUser != null) {
                        handleFirestoreError(exceptionToLog, OperationType.LIST, path)
                    }
                    throw error
                }
        )
    }

    suspend fun seedInitialTournamentsIfEmpty() = withContext(Dispatchers.IO) {
        val path = "tournaments"
        try {
            val snapshot = db.collection(path).limit(1).get().await()
            if (snapshot.isEmpty) {
                val initialTournament = Tournament(
                    tournamentId = "tournament_ammar_grand",
                    title = "بطولة عمار الكبرى",
                    date = "السبت 15 نوفمبر",
                    dayName = "السبت",
                    dayNumber = 15,
                    monthName = "نوفمبر",
                    time = "الساعة 9:00 مساءً",
                    map = "سانهوك",
                    maxTeams = 64,
                    registeredTeams = 42,
                    status = "open",
                    statusLabel = "قيد التسجيل",
                    description = "البطولة الكبرى الشهرية بتنظيم الكابتن عمار أبو دقه. مجموع الجوائز 500$ + بطاقات رويال باس ومكافآت حصرية للفرق الفائزة بالصدارة.",
                    registeredUserIds = emptyList()
                )
                val docRef = db.collection(path).document(initialTournament.tournamentId)
                val payload = mapOf(
                    "tournamentId" to initialTournament.tournamentId,
                    "title" to initialTournament.title,
                    "date" to initialTournament.date,
                    "dayName" to initialTournament.dayName,
                    "dayNumber" to initialTournament.dayNumber,
                    "monthName" to initialTournament.monthName,
                    "time" to initialTournament.time,
                    "map" to initialTournament.map,
                    "maxTeams" to initialTournament.maxTeams,
                    "registeredTeams" to initialTournament.registeredTeams,
                    "status" to initialTournament.status,
                    "statusLabel" to initialTournament.statusLabel,
                    "description" to initialTournament.description,
                    "registeredUserIds" to emptyList<String>(),
                    "createdAt" to FieldValue.serverTimestamp()
                )
                docRef.set(payload).await()
            }
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, path)
        }
    }

    /**
     * Atomic registration using Firestore Transaction to prevent race conditions
     * and strictly enforce team quotas.
     */
    suspend fun registerForTournament(tournamentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: return@withContext Result.failure(
            IllegalStateException("يجب تسجيل الدخول أولاً")
        )
        val docRef = db.collection("tournaments").document(tournamentId)
        try {
            db.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                if (!snapshot.exists()) {
                    throw IllegalStateException("البطولة غير موجودة")
                }
                val currentRegistered = snapshot.getLong("registeredTeams")?.toInt() ?: 0
                val maxTeams = snapshot.getLong("maxTeams")?.toInt() ?: 64
                @Suppress("UNCHECKED_CAST")
                val userList = (snapshot.get("registeredUserIds") as? List<String>) ?: emptyList()

                if (userList.contains(uid)) {
                    throw IllegalStateException("أنت مسجل بالفعل في هذه البطولة")
                }
                if (currentRegistered >= maxTeams) {
                    throw IllegalStateException("اكتمل العدد المطلوب للفرق ولا يمكن التسجيل")
                }

                val updatedList = userList + uid
                transaction.update(docRef, "registeredTeams", currentRegistered + 1)
                transaction.update(docRef, "registeredUserIds", updatedList)
                transaction.update(docRef, "updatedAt", FieldValue.serverTimestamp())
            }.await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    /**
     * Cancel registration using Firestore Transaction
     */
    suspend fun unregisterFromTournament(tournamentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val uid = auth.currentUser?.uid ?: return@withContext Result.failure(
            IllegalStateException("يجب تسجيل الدخول أولاً")
        )
        val docRef = db.collection("tournaments").document(tournamentId)
        try {
            db.runTransaction { transaction ->
                val snapshot = transaction.get(docRef)
                if (!snapshot.exists()) {
                    throw IllegalStateException("البطولة غير موجودة")
                }
                val currentRegistered = snapshot.getLong("registeredTeams")?.toInt() ?: 0
                @Suppress("UNCHECKED_CAST")
                val userList = (snapshot.get("registeredUserIds") as? List<String>) ?: emptyList()

                if (!userList.contains(uid)) {
                    throw IllegalStateException("أنت غير مسجل في هذه البطولة")
                }

                val updatedList = userList - uid
                val newCount = if (currentRegistered > 0) currentRegistered - 1 else 0
                transaction.update(docRef, "registeredTeams", newCount)
                transaction.update(docRef, "registeredUserIds", updatedList)
                transaction.update(docRef, "updatedAt", FieldValue.serverTimestamp())
            }.await()

            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun addTournament(tournament: Tournament): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("tournaments").document(tournament.tournamentId)
        try {
            val payload = mapOf(
                "tournamentId" to tournament.tournamentId,
                "title" to tournament.title,
                "date" to tournament.date,
                "dayName" to tournament.dayName,
                "dayNumber" to tournament.dayNumber,
                "monthName" to tournament.monthName,
                "time" to tournament.time,
                "map" to tournament.map,
                "maxTeams" to tournament.maxTeams,
                "registeredTeams" to 0,
                "status" to tournament.status,
                "statusLabel" to tournament.statusLabel,
                "description" to tournament.description,
                "imageURL" to tournament.imageURL,
                "registeredUserIds" to emptyList<String>(),
                "createdAt" to FieldValue.serverTimestamp()
            )
            docRef.set(payload).await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun updateTournament(tournament: Tournament): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("tournaments").document(tournament.tournamentId)
        try {
            val updates = mutableMapOf<String, Any>(
                "title" to tournament.title,
                "date" to tournament.date,
                "time" to tournament.time,
                "map" to tournament.map,
                "maxTeams" to tournament.maxTeams,
                "status" to tournament.status,
                "statusLabel" to tournament.statusLabel,
                "description" to tournament.description,
                "imageURL" to tournament.imageURL,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            docRef.update(updates).await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            Result.failure(e)
        }
    }

    suspend fun deleteTournament(tournamentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        val docRef = db.collection("tournaments").document(tournamentId)
        try {
            docRef.delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            Result.failure(e)
        }
    }
}
