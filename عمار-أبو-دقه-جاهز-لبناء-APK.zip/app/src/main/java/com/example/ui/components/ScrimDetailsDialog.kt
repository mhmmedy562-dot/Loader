package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Scrim
import com.example.ui.theme.GoldButtonGradient
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PubgCardBorder
import com.example.ui.theme.PubgInputBg
import com.example.ui.theme.PubgInputBorder
import com.example.ui.theme.ScrimGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun ScrimDetailsDialog(
    scrim: Scrim,
    currentUserId: String,
    onDismiss: () -> Unit,
    onRegister: suspend (String) -> Result<Unit>,
    onUnregister: suspend (String) -> Result<Unit>
) {
    val coroutineScope = rememberCoroutineScope()
    var teamName by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }
    var resultMessage by remember { mutableStateOf<String?>(null) }
    var isSuccess by remember { mutableStateOf(false) }

    val isRegistered = scrim.registeredUserIds.contains(currentUserId)

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        AlertDialog(
            onDismissRequest = onDismiss,
            containerColor = Color(0xFF171410),
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = scrim.title,
                        color = GoldPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Match Info Details
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF201C16))
                            .border(1.dp, PubgCardBorder, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AccessTime, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "${scrim.date} - ${scrim.time}", color = TextWhite, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Map, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "الخريطة: ${scrim.map}", color = TextWhite, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Groups, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "الفرق المسجلة: ${scrim.registeredTeams} / ${scrim.maxTeams}", color = TextWhite, fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (isRegistered) {
                        // Room details unlocked!
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x3322C55E))
                                .border(1.dp, ScrimGreen, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ScrimGreen, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "أنت مسجل في هذا الاسكرم!", color = ScrimGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "رقم الغرفة (ID): ${scrim.roomId.ifBlank { "PUBG-8842" }}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Key, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(text = "كلمة المرور (PW): ${scrim.roomPassword.ifBlank { "AMMAR" }}", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "وقت دخول الروم: ${scrim.roomVisibleAt}", color = TextMuted, fontSize = 11.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Cancel registration button
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0x22EF4444))
                                .border(1.dp, Color(0xFFEF4444), RoundedCornerShape(10.dp))
                                .clickable(enabled = !isSubmitting) {
                                    isSubmitting = true
                                    resultMessage = null
                                    coroutineScope.launch {
                                        val res = onUnregister(scrim.scrimId)
                                        isSubmitting = false
                                        if (res.isSuccess) {
                                            isSuccess = true
                                            resultMessage = "تم إلغاء التسجيل واسترجاع المقعد بنجاح"
                                        } else {
                                            isSuccess = false
                                            resultMessage = res.exceptionOrNull()?.localizedMessage ?: "حدث خطأ أثناء إلغاء التسجيل"
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSubmitting) {
                                CircularProgressIndicator(color = Color(0xFFEF4444), modifier = Modifier.size(18.dp))
                            } else {
                                Text("إلغاء التسجيل من الاسكرم", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    } else {
                        // Registration Input
                        Text(
                            text = "تسجيل فريقك في الاسكرم:",
                            color = TextWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = teamName,
                            onValueChange = { teamName = it },
                            placeholder = { Text("اسم الكلان / الفريق (مثال: Falcon Clan)", color = TextMuted, fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = PubgInputBg,
                                unfocusedContainerColor = PubgInputBg,
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = PubgInputBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            )
                        )
                    }

                    if (resultMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = resultMessage!!,
                            color = if (isSuccess) ScrimGreen else Color(0xFFFF5252),
                            fontSize = 13.sp
                        )
                    }
                }
            },
            confirmButton = {
                if (!isRegistered) {
                    Box(
                        modifier = Modifier
                            .height(44.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GoldButtonGradient)
                            .clickable(enabled = !isSubmitting) {
                                if (teamName.isBlank()) {
                                    resultMessage = "يرجى كتابة اسم الفريق أو الكلان"
                                    isSuccess = false
                                } else {
                                    isSubmitting = true
                                    resultMessage = null
                                    coroutineScope.launch {
                                        val res = onRegister(scrim.scrimId)
                                        isSubmitting = false
                                        if (res.isSuccess) {
                                            isSuccess = true
                                            resultMessage = "تم تسجيل الفريق بنجاح في الاسكرم!"
                                        } else {
                                            isSuccess = false
                                            resultMessage = res.exceptionOrNull()?.localizedMessage ?: "حدث خطأ أثناء التسجيل"
                                        }
                                    }
                                }
                            }
                            .padding(horizontal = 20.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(color = Color.Black, modifier = Modifier.size(20.dp))
                        } else {
                            Text("تأكيد التسجيل", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = onDismiss) {
                    Text("إغلاق", color = TextMuted)
                }
            }
        )
    }
}
