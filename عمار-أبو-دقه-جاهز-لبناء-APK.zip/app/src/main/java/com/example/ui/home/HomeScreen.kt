package com.example.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppNotification
import com.example.data.model.GlobalStats
import com.example.data.model.Scrim
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.data.repository.AuthRepository
import com.example.data.repository.NotificationRepository
import com.example.data.repository.ScrimRepository
import com.example.data.repository.StatsRepository
import com.example.data.repository.TournamentRepository
import com.example.ui.components.AdminPanelDialog
import com.example.ui.components.BottomNavBar
import com.example.ui.components.HeaderBar
import com.example.ui.components.HeroBanner
import com.example.ui.components.NotificationsSheet
import com.example.ui.components.ScrimCard
import com.example.ui.components.ScrimDetailsDialog
import com.example.ui.components.SettingsSheet
import com.example.ui.components.StatsRow
import com.example.ui.components.TournamentCard
import com.example.ui.components.TournamentDetailsDialog
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.PubgBlack
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    currentUserId: String,
    authRepository: AuthRepository,
    scrimRepository: ScrimRepository,
    tournamentRepository: TournamentRepository,
    notificationRepository: NotificationRepository,
    statsRepository: StatsRepository,
    onSignOut: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    var userProfile by remember { mutableStateOf<UserProfile?>(null) }
    val scrims by scrimRepository.observeScrims().collectAsState(initial = emptyList())
    val tournaments by tournamentRepository.observeTournaments().collectAsState(initial = emptyList())
    val notifications by notificationRepository.observeUserNotifications().collectAsState(initial = emptyList())
    val stats by statsRepository.observeStats().collectAsState(initial = GlobalStats())

    var selectedScrim by remember { mutableStateOf<Scrim?>(null) }
    var selectedTournament by remember { mutableStateOf<Tournament?>(null) }
    var showNotificationsSheet by remember { mutableStateOf(false) }
    var showSettingsSheet by remember { mutableStateOf(false) }
    var showAdminPanel by remember { mutableStateOf(false) }

    val unreadCount = notifications.count { !it.isRead }

    // Seed initial events and load profile
    LaunchedEffect(currentUserId) {
        userProfile = authRepository.getUserProfile(currentUserId)
        scrimRepository.seedInitialScrimsIfEmpty()
        tournamentRepository.seedInitialTournamentsIfEmpty()
        notificationRepository.seedInitialNotificationsIfEmpty()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = PubgBlack,
            bottomBar = {
                BottomNavBar()
            }
        ) { innerPadding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // A. HEADER BAR MATCHING IMAGE 2
                item {
                    val displayName = userProfile?.inGameName?.ifBlank { userProfile?.fullName } ?: "محمد أحمد"
                    val displayId = userProfile?.inGameId?.ifBlank { userProfile?.userId?.take(8) } ?: "12345678"
                    HeaderBar(
                        userName = displayName,
                        userId = displayId,
                        unreadNotificationsCount = unreadCount,
                        onNotificationsClick = { showNotificationsSheet = true },
                        onSettingsClick = { showSettingsSheet = true }
                    )
                }

                // B. HERO BANNER MATCHING IMAGE 2
                item {
                    HeroBanner()
                }

                // C. STATISTICS ROW MATCHING IMAGE 2
                item {
                    StatsRow(
                        tournamentsCount = stats.upcomingTournamentsCount,
                        playersCountStr = if (stats.registeredPlayersCount >= 1000) "${stats.registeredPlayersCount / 1000}K+" else "${stats.registeredPlayersCount}",
                        monthlyScrimsCount = stats.monthlyScrimsCount
                    )
                }

                // D. UPCOMING SCRIMS SECTION HEADER MATCHING IMAGE 2
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "الاسكرمات القادمة",
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        // "عرض الكل <" Gold Pill Button matching IMAGE 2
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(GoldPrimary)
                                .clickable { /* View all scrims */ }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "عرض الكل",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }
                }

                // Scrim Cards
                if (scrims.isEmpty()) {
                    item {
                        // Render default preview scrim matching IMAGE 2 while loading
                        val defaultScrim = Scrim(
                            scrimId = "scrim_friday_weekly",
                            title = "اسكرم الجمعة الأسبوعي",
                            date = "الجمعة 14 نوفمبر",
                            dayName = "الجمعة",
                            dayNumber = 14,
                            monthName = "نوفمبر",
                            time = "الساعة 8:00 مساءً",
                            map = "إرانغل",
                            maxTeams = 20,
                            registeredTeams = 18,
                            status = "open",
                            statusLabel = "مفتوح التسجيل"
                        )
                        ScrimCard(
                            scrim = defaultScrim,
                            onRegisterClick = { selectedScrim = defaultScrim }
                        )
                    }
                } else {
                    items(scrims) { scrim ->
                        ScrimCard(
                            scrim = scrim,
                            onRegisterClick = { selectedScrim = scrim }
                        )
                    }
                }

                // E. UPCOMING TOURNAMENTS SECTION HEADER MATCHING IMAGE 2
                item {
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "البطولات القادمة",
                            color = TextWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Tournament Cards
                if (tournaments.isEmpty()) {
                    item {
                        val defaultTournament = Tournament(
                            tournamentId = "tournament_ammar_grand",
                            title = "بطولة عمار الكبرى",
                            date = "السبت 15 نوفمبر",
                            dayName = "السبت",
                            dayNumber = 15,
                            monthName = "نوفمبر",
                            time = "الساعة 9:00 مساءً",
                            map = "سانهوك",
                            maxTeams = 64,
                            registeredTeams = 42,
                            status = "open",
                            statusLabel = "قيد التسجيل"
                        )
                        TournamentCard(
                            tournament = defaultTournament,
                            onDetailsClick = { selectedTournament = defaultTournament }
                        )
                    }
                } else {
                    items(tournaments) { tournament ->
                        TournamentCard(
                            tournament = tournament,
                            onDetailsClick = { selectedTournament = tournament }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }

            // Scrim Registration / Details Dialog
            selectedScrim?.let { scrim ->
                ScrimDetailsDialog(
                    scrim = scrim,
                    currentUserId = currentUserId,
                    onDismiss = { selectedScrim = null },
                    onRegister = { id -> scrimRepository.registerForScrim(id) },
                    onUnregister = { id -> scrimRepository.unregisterFromScrim(id) }
                )
            }

            // Tournament Details Dialog
            selectedTournament?.let { tournament ->
                TournamentDetailsDialog(
                    tournament = tournament,
                    currentUserId = currentUserId,
                    onDismiss = { selectedTournament = null },
                    onRegister = { id -> tournamentRepository.registerForTournament(id) },
                    onUnregister = { id -> tournamentRepository.unregisterFromTournament(id) }
                )
            }

            // Notifications Sheet
            if (showNotificationsSheet) {
                NotificationsSheet(
                    notifications = notifications,
                    onDismiss = { showNotificationsSheet = false },
                    onMarkAsRead = { id ->
                        coroutineScope.launch { notificationRepository.markAsRead(id) }
                    }
                )
            }

            // Settings Sheet
            if (showSettingsSheet) {
                SettingsSheet(
                    profile = userProfile,
                    onDismiss = { showSettingsSheet = false },
                    onSignOut = {
                        authRepository.signOut(coroutineScope) {
                            onSignOut()
                        }
                    },
                    onOpenAdminPanel = {
                        showAdminPanel = true
                    }
                )
            }

            // Admin Control Panel Dialog
            if (showAdminPanel) {
                AdminPanelDialog(
                    scrims = scrims,
                    tournaments = tournaments,
                    onDismiss = { showAdminPanel = false },
                    onAddScrim = { newScrim -> scrimRepository.addScrim(newScrim) },
                    onDeleteScrim = { scrimId -> scrimRepository.deleteScrim(scrimId) },
                    onAddTournament = { newTourn -> tournamentRepository.addTournament(newTourn) },
                    onDeleteTournament = { tournId -> tournamentRepository.deleteTournament(tournId) }
                )
            }
        }
    }
}
