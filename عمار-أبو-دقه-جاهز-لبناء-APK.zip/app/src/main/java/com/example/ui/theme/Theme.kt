package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val PubgDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = GoldDark,
    onPrimaryContainer = Color.White,
    secondary = AmberFire,
    onSecondary = Color.Black,
    tertiary = GoldLight,
    background = PubgBlack,
    onBackground = TextWhite,
    surface = PubgSurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = PubgCardBg,
    onSurfaceVariant = TextMuted,
    outline = PubgCardBorder
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PubgDarkColorScheme,
        typography = Typography,
        content = content
    )
}
